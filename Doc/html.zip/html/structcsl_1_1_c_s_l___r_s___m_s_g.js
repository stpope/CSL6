var structcsl_1_1_c_s_l___r_s___m_s_g =
[
    [ "magic", "structcsl_1_1_c_s_l___r_s___m_s_g.html#a8d456b6d68103e132bc14b1fb6aaeb91", null ],
    [ "frames", "structcsl_1_1_c_s_l___r_s___m_s_g.html#a80b001f742ed6b1a6c20c5842aac3f85", null ],
    [ "channels", "structcsl_1_1_c_s_l___r_s___m_s_g.html#a3226a0b7751a208e28ecddda5fd1cbcd", null ]
];