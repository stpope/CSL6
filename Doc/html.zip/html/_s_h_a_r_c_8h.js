var _s_h_a_r_c_8h =
[
    [ "SHARCSpectrum", "classcsl_1_1_s_h_a_r_c_spectrum.html", "classcsl_1_1_s_h_a_r_c_spectrum" ],
    [ "SHARCInstrument", "classcsl_1_1_s_h_a_r_c_instrument.html", "classcsl_1_1_s_h_a_r_c_instrument" ],
    [ "SHARCLibrary", "classcsl_1_1_s_h_a_r_c_library.html", "classcsl_1_1_s_h_a_r_c_library" ],
    [ "MAX_PARTIALS", "_s_h_a_r_c_8h.html#a923241155641730eccdf3034986f2b91", null ],
    [ "MAX_SPECTRA", "_s_h_a_r_c_8h.html#a9e9bb11a1bc26e2e959df2219dac9802", null ],
    [ "MAX_INSTRUMENTS", "_s_h_a_r_c_8h.html#a15b12bc8e78d7628fed07a351204903c", null ]
];