var structcsl_1_1test_struct =
[
    [ "name", "structcsl_1_1test_struct.html#a60d232bca6483c3622d79e590e8532b7", null ],
    [ "fcn", "structcsl_1_1test_struct.html#a6082590d70d6688e47d9d23f74313f29", null ],
    [ "comment", "structcsl_1_1test_struct.html#a1754263ae06c963a9d252aee973f4669", null ]
];