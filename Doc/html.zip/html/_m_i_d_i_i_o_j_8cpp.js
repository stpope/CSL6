var _m_i_d_i_i_o_j_8cpp =
[
    [ "CCOPY_MSG", "_m_i_d_i_i_o_j_8cpp.html#a1286ee63f4fa19da88f9528429f6a765", null ],
    [ "gAudioDeviceManager", "_m_i_d_i_i_o_j_8cpp.html#aa234e60809560475361878578c96e6eb", null ]
];