var _spectral_8h =
[
    [ "FFT", "classcsl_1_1_f_f_t.html", "classcsl_1_1_f_f_t" ],
    [ "IFFT", "classcsl_1_1_i_f_f_t.html", "classcsl_1_1_i_f_f_t" ],
    [ "USE_FFTW", "_spectral_8h.html#a0ac4389428002ffb7b15d4d26487d478", null ]
];