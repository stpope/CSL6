var classcsl_1_1_logic_error =
[
    [ "LogicError", "classcsl_1_1_logic_error.html#acbe532e31b7c05c38b6d6dd98eed7b36", null ],
    [ "what", "classcsl_1_1_logic_error.html#aaa80baf48d8b2a9af6d5bce2d1b27388", null ],
    [ "mMessage", "classcsl_1_1_logic_error.html#a82f57e285f07ca934823977ed3d364e3", null ]
];