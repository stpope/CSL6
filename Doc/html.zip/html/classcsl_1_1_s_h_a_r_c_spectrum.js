var classcsl_1_1_s_h_a_r_c_spectrum =
[
    [ "SHARCSpectrum", "classcsl_1_1_s_h_a_r_c_spectrum.html#af5154041597f22ff432d8207875864fe", null ],
    [ "~SHARCSpectrum", "classcsl_1_1_s_h_a_r_c_spectrum.html#a448a641791ed62e4c32e8b4e6368336f", null ],
    [ "read_from_file", "classcsl_1_1_s_h_a_r_c_spectrum.html#afd8592b4a0589138243ed4c24e2e051e", null ],
    [ "count_partials", "classcsl_1_1_s_h_a_r_c_spectrum.html#a0d3247f3fb4890b414c61fc767893b1c", null ],
    [ "dump_example", "classcsl_1_1_s_h_a_r_c_spectrum.html#add29f56aadbcffd51fb427740b844894", null ],
    [ "_note_name", "classcsl_1_1_s_h_a_r_c_spectrum.html#ab6efba78609dc5e94ea333ab4352d4d7", null ],
    [ "_midi_key", "classcsl_1_1_s_h_a_r_c_spectrum.html#a686fdcc2fe4056db6ae9690a45349134", null ],
    [ "_nom_pitch", "classcsl_1_1_s_h_a_r_c_spectrum.html#ad290d565fb0f462e9c87130749f4d548", null ],
    [ "_actual_pitch", "classcsl_1_1_s_h_a_r_c_spectrum.html#a4ff268690cd4df5239a755e43de1c747", null ],
    [ "_max_amp", "classcsl_1_1_s_h_a_r_c_spectrum.html#a3897c6457b5f43b4c178335e3b7d3f5a", null ],
    [ "_num_partials", "classcsl_1_1_s_h_a_r_c_spectrum.html#a9aae6f3c2ab3824537748223976ae90d", null ],
    [ "_partials", "classcsl_1_1_s_h_a_r_c_spectrum.html#ad0c0ee21134a46615de1c81348dcb661", null ]
];