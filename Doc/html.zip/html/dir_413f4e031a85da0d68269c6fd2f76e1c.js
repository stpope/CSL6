var dir_413f4e031a85da0d68269c6fd2f76e1c =
[
    [ "Instruments", "dir_48bba90875b185724f5b40b482a87bb9.html", "dir_48bba90875b185724f5b40b482a87bb9" ],
    [ "IO", "dir_8b17484df95ad01ced4ea0c779f5aa28.html", "dir_8b17484df95ad01ced4ea0c779f5aa28" ],
    [ "JUCE", "dir_53a40247f2102c499bd94719692985af.html", "dir_53a40247f2102c499bd94719692985af" ],
    [ "Kernel", "dir_160e07ed0247b6847ccdfaf372b0a65e.html", "dir_160e07ed0247b6847ccdfaf372b0a65e" ],
    [ "Processors", "dir_6e6beba01af919999014f11f0371d9ca.html", "dir_6e6beba01af919999014f11f0371d9ca" ],
    [ "Sources", "dir_ff6a1da56cf959260392e4ec2ad8edc0.html", "dir_ff6a1da56cf959260392e4ec2ad8edc0" ],
    [ "Spatializers", "dir_ace40378faa21e0ea8c19f9d882aec63.html", "dir_ace40378faa21e0ea8c19f9d882aec63" ],
    [ "Tests", "dir_d7ee8d30e27f2f90e9dbe2771d277927.html", "dir_d7ee8d30e27f2f90e9dbe2771d277927" ],
    [ "Utilities", "dir_0c6edeca5fab95ce7c31a8ec588ee29f.html", "dir_0c6edeca5fab95ce7c31a8ec588ee29f" ]
];