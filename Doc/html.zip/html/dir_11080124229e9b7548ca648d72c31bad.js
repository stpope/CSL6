var dir_11080124229e9b7548ca648d72c31bad =
[
    [ "BinaryOp.cpp", "_binary_op_8cpp.html", null ],
    [ "BinaryOp.h", "_binary_op_8h.html", "_binary_op_8h" ],
    [ "Clipper.cpp", "_clipper_8cpp.html", null ],
    [ "Clipper.h", "_clipper_8h.html", "_clipper_8h" ],
    [ "Convolver.cpp", "_convolver_8cpp.html", null ],
    [ "Convolver.h", "_processors_2_convolver_8h.html", [
      [ "Convolver", "classcsl_1_1_convolver.html", "classcsl_1_1_convolver" ]
    ] ],
    [ "Convolver2.cpp", "_convolver2_8cpp.html", null ],
    [ "Convolver2.h", "_convolver2_8h.html", "_convolver2_8h" ],
    [ "Filters.cpp", "_filters_8cpp.html", null ],
    [ "Filters.h", "_filters_8h.html", "_filters_8h" ],
    [ "FIR.cpp", "_f_i_r_8cpp.html", "_f_i_r_8cpp" ],
    [ "FIR.h", "_f_i_r_8h.html", [
      [ "FilterSpecification", "classcsl_1_1_filter_specification.html", "classcsl_1_1_filter_specification" ],
      [ "FIR", "classcsl_1_1_f_i_r.html", "classcsl_1_1_f_i_r" ]
    ] ],
    [ "Freeverb.cpp", "_freeverb_8cpp.html", "_freeverb_8cpp" ],
    [ "Freeverb.h", "_freeverb_8h.html", "_freeverb_8h" ],
    [ "InOut.cpp", "_in_out_8cpp.html", null ],
    [ "InOut.h", "_in_out_8h.html", "_in_out_8h" ],
    [ "Mixer.cpp", "_mixer_8cpp.html", null ],
    [ "Mixer.h", "_mixer_8h.html", "_mixer_8h" ]
];