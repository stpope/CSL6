var _test___o_s_c___client_8cpp =
[
    [ "NUM_NOTES", "_test___o_s_c___client_8cpp.html#a5b0b677cb9527865430a9b3d7a71cb03", null ],
    [ "noteLoop", "_test___o_s_c___client_8cpp.html#a57dae1f466faace0b8a58cc775a7002f", null ],
    [ "main", "_test___o_s_c___client_8cpp.html#a9adec5b0ff06247a1ee2406b34464192", null ]
];