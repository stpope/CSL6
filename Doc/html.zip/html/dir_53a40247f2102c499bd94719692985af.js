var dir_53a40247f2102c499bd94719692985af =
[
    [ "CSL_AbstComponent.cpp", "_c_s_l___abst_component_8cpp.html", "_c_s_l___abst_component_8cpp" ],
    [ "CSL_AbstComponent.h", "_c_s_l___abst_component_8h.html", "_c_s_l___abst_component_8h" ],
    [ "CSL_ServerComponent.cpp", "_c_s_l___server_component_8cpp.html", "_c_s_l___server_component_8cpp" ],
    [ "CSL_ServerComponent.h", "_c_s_l___server_component_8h.html", [
      [ "CSLServerComponent", "class_c_s_l_server_component.html", "class_c_s_l_server_component" ]
    ] ],
    [ "CSL_TestComponent.cpp", "_c_s_l___test_component_8cpp.html", "_c_s_l___test_component_8cpp" ],
    [ "CSL_TestComponent.h", "_c_s_l___test_component_8h.html", "_c_s_l___test_component_8h" ],
    [ "CSLMIDIComponent.cpp", "_c_s_l_m_i_d_i_component_8cpp.html", "_c_s_l_m_i_d_i_component_8cpp" ],
    [ "CSLMIDIComponent.h", "_c_s_l_m_i_d_i_component_8h.html", [
      [ "CSLMIDIComponent", "class_c_s_l_m_i_d_i_component.html", "class_c_s_l_m_i_d_i_component" ]
    ] ],
    [ "CSLMIDIFaderComponent.cpp", "_c_s_l_m_i_d_i_fader_component_8cpp.html", "_c_s_l_m_i_d_i_fader_component_8cpp" ],
    [ "CSLMIDIFaderComponent.h", "_c_s_l_m_i_d_i_fader_component_8h.html", [
      [ "CSLMIDIComponent", "class_c_s_l_m_i_d_i_component.html", "class_c_s_l_m_i_d_i_component" ]
    ] ],
    [ "JCSL_Widgets.cpp", "_j_c_s_l___widgets_8cpp.html", "_j_c_s_l___widgets_8cpp" ],
    [ "JCSL_Widgets.h", "_j_c_s_l___widgets_8h.html", "_j_c_s_l___widgets_8h" ],
    [ "Main.cpp", "_main_8cpp.html", "_main_8cpp" ],
    [ "MainMIDI.cpp", "_main_m_i_d_i_8cpp.html", "_main_m_i_d_i_8cpp" ],
    [ "MainServer.cpp", "_main_server_8cpp.html", "_main_server_8cpp" ],
    [ "SpectralProc.cpp", "_spectral_proc_8cpp.html", "_spectral_proc_8cpp" ],
    [ "SpectralProc.h", "_spectral_proc_8h.html", [
      [ "CSLComponent", "class_c_s_l_component.html", "class_c_s_l_component" ]
    ] ]
];