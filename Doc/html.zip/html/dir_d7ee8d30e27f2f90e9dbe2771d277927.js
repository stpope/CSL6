var dir_d7ee8d30e27f2f90e9dbe2771d277927 =
[
    [ "OSC", "dir_f1b63fb8c2cf8d0e64e35bc7b886e85a.html", "dir_f1b63fb8c2cf8d0e64e35bc7b886e85a" ],
    [ "FilterData.h", "_filter_data_8h.html", "_filter_data_8h" ],
    [ "Test_Audio.cpp", "_test___audio_8cpp.html", "_test___audio_8cpp" ],
    [ "Test_Control.cpp", "_test___control_8cpp.html", "_test___control_8cpp" ],
    [ "Test_Effects.cpp", "_test___effects_8cpp.html", "_test___effects_8cpp" ],
    [ "Test_Envelopes.cpp", "_test___envelopes_8cpp.html", "_test___envelopes_8cpp" ],
    [ "Test_Oscillators.cpp", "_test___oscillators_8cpp.html", "_test___oscillators_8cpp" ],
    [ "Test_Panners.cpp", "_test___panners_8cpp.html", "_test___panners_8cpp" ],
    [ "Test_Sources.cpp", "_test___sources_8cpp.html", "_test___sources_8cpp" ],
    [ "Test_Support.cpp", "_test___support_8cpp.html", "_test___support_8cpp" ],
    [ "Test_Support.h", "_test___support_8h.html", "_test___support_8h" ]
];