var _ambisonic_8h =
[
    [ "AmbisonicOrder", "classcsl_1_1_ambisonic_order.html", "classcsl_1_1_ambisonic_order" ],
    [ "AmbisonicUnitGenerator", "classcsl_1_1_ambisonic_unit_generator.html", "classcsl_1_1_ambisonic_unit_generator" ],
    [ "AmbisonicEncoder", "classcsl_1_1_ambisonic_encoder.html", "classcsl_1_1_ambisonic_encoder" ],
    [ "AmbisonicDecoder", "classcsl_1_1_ambisonic_decoder.html", "classcsl_1_1_ambisonic_decoder" ],
    [ "HOA_MAX_ORDER", "_ambisonic_8h.html#a5b103a0f555976cfa28d60633ee94d76", null ],
    [ "AmbisonicDecoderMethod", "_ambisonic_8h.html#a6eb455fefa5dbe2d2e2ac940a9fe8a53", [
      [ "kPSEUDOINVERSE", "_ambisonic_8h.html#a6eb455fefa5dbe2d2e2ac940a9fe8a53ad3a4e2d8ddc4459eb74255672c5e5516", null ],
      [ "kPROJECTION", "_ambisonic_8h.html#a6eb455fefa5dbe2d2e2ac940a9fe8a53adc71e2ca19a515b683d445075347a322", null ]
    ] ],
    [ "AmbisonicDecoderFlavour", "_ambisonic_8h.html#a5c85f74d4716858c62c3d50f45d4b68e", [
      [ "kBASIC", "_ambisonic_8h.html#a5c85f74d4716858c62c3d50f45d4b68eabce9238d0ff7e501a9e0e69b6bce8a20", null ],
      [ "kINPHASE", "_ambisonic_8h.html#a5c85f74d4716858c62c3d50f45d4b68ea823d0f5107cb7f572f01f0383bf33b47", null ],
      [ "kMAXRE", "_ambisonic_8h.html#a5c85f74d4716858c62c3d50f45d4b68eadc2e2840e7ee71f287816567ea7cee0f", null ]
    ] ]
];