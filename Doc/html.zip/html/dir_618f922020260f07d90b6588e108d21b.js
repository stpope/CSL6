var dir_618f922020260f07d90b6588e108d21b =
[
    [ "WaveShaper.cpp", "_old_2_wave_shaper_8cpp.html", null ],
    [ "WaveShaper.h", "_old_2_wave_shaper_8h.html", [
      [ "WaveShaper", "classcsl_1_1_wave_shaper.html", "classcsl_1_1_wave_shaper" ]
    ] ]
];