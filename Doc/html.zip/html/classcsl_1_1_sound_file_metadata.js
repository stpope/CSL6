var classcsl_1_1_sound_file_metadata =
[
    [ "SoundFileMetadata", "classcsl_1_1_sound_file_metadata.html#a31a00e872606c6828c160af664b930f2", null ],
    [ "~SoundFileMetadata", "classcsl_1_1_sound_file_metadata.html#ac64282b646a083067e1960675f0a51d1", null ],
    [ "dump", "classcsl_1_1_sound_file_metadata.html#ac180873569f0c5ca65e28757bc29deb2", null ],
    [ "mTitle", "classcsl_1_1_sound_file_metadata.html#ab72d0648b9f4cd0437d3986016322975", null ],
    [ "mArtist", "classcsl_1_1_sound_file_metadata.html#a593d5cdd4d8d34069fd9f5103ee8a420", null ],
    [ "mAlbum", "classcsl_1_1_sound_file_metadata.html#a7121a3346a8fc24d155c0e228e28e6d2", null ],
    [ "mYear", "classcsl_1_1_sound_file_metadata.html#a8fdda6d9d6711e68a9700d3d201389ab", null ],
    [ "mComment", "classcsl_1_1_sound_file_metadata.html#a0e32b6bef3a5e01ca2322e107718018a", null ],
    [ "mTrack", "classcsl_1_1_sound_file_metadata.html#aa87b42defb46209788f1c354c56c3e1d", null ],
    [ "mGenre", "classcsl_1_1_sound_file_metadata.html#af16ecd336903a265adf3133016724777", null ],
    [ "mBitRate", "classcsl_1_1_sound_file_metadata.html#a31ae04ff17e89b2f7dd543f5b7e0e26a", null ],
    [ "mSampleRate", "classcsl_1_1_sound_file_metadata.html#aceca304906394a27c1bf4ba87fa7d2b7", null ],
    [ "mChannels", "classcsl_1_1_sound_file_metadata.html#a3e64636ef8e90ca0310723d0d559fc0c", null ],
    [ "mLength", "classcsl_1_1_sound_file_metadata.html#acfd978e85028dc9d6743268b38900076", null ]
];