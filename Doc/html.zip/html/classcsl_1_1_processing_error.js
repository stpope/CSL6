var classcsl_1_1_processing_error =
[
    [ "ProcessingError", "classcsl_1_1_processing_error.html#ac8a52bae0cc8b5f4b5370c92f4f23923", null ],
    [ "what", "classcsl_1_1_processing_error.html#aaa80baf48d8b2a9af6d5bce2d1b27388", null ],
    [ "mMessage", "classcsl_1_1_processing_error.html#a82f57e285f07ca934823977ed3d364e3", null ]
];