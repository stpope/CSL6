var classcsl_1_1_ambisonic_order =
[
    [ "AmbisonicOrder", "classcsl_1_1_ambisonic_order.html#a8b6ab47842877ffa40d15830dca38eb3", null ],
    [ "~AmbisonicOrder", "classcsl_1_1_ambisonic_order.html#a5eb327b76104018694795c2f34ad3625", null ],
    [ "horizontalOrder", "classcsl_1_1_ambisonic_order.html#a9e329743505e0ed415cc05b9eb32484f", null ],
    [ "verticalOrder", "classcsl_1_1_ambisonic_order.html#a51ee6fbca9c0f92d7c217d41366d900f", null ],
    [ "isUniform", "classcsl_1_1_ambisonic_order.html#ad74320be896d028dee9ef1a962c51d5b", null ]
];