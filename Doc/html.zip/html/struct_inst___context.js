var struct_inst___context =
[
    [ "instr", "struct_inst___context.html#a59a7b3fa10a23d013ba5f9ea62a45523", null ],
    [ "num", "struct_inst___context.html#ac4893d4e9263515560e6f03f8451f23c", null ],
    [ "selector", "struct_inst___context.html#af1e7bb623c1dadf37a4b55973ace856b", null ]
];