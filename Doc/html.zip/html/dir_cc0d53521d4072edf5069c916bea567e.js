var dir_cc0d53521d4072edf5069c916bea567e =
[
    [ "Ambisonic", "dir_39160170b87398f47e00abe59a2d13bc.html", "dir_39160170b87398f47e00abe59a2d13bc" ],
    [ "Binaural", "dir_27157b5fe6d16e632c3ade4600eb29fe.html", "dir_27157b5fe6d16e632c3ade4600eb29fe" ],
    [ "RoomAcoustics", "dir_aa4f1cb1515f5c50ebe61a031bc9b551.html", "dir_aa4f1cb1515f5c50ebe61a031bc9b551" ],
    [ "VBAP", "dir_654af49fab6848cbfee3fb0c4f890a57.html", "dir_654af49fab6848cbfee3fb0c4f890a57" ],
    [ "DistanceSimulator.cpp", "_distance_simulator_8cpp.html", null ],
    [ "DistanceSimulator.h", "_distance_simulator_8h.html", [
      [ "DistanceSimulator", "classcsl_1_1_distance_simulator.html", "classcsl_1_1_distance_simulator" ],
      [ "DistanceCue", "classcsl_1_1_distance_cue.html", "classcsl_1_1_distance_cue" ],
      [ "IntensityAttenuationCue", "classcsl_1_1_intensity_attenuation_cue.html", "classcsl_1_1_intensity_attenuation_cue" ],
      [ "AirAbsorptionCue", "classcsl_1_1_air_absorption_cue.html", "classcsl_1_1_air_absorption_cue" ]
    ] ],
    [ "matrix.h", "_spatializers_2matrix_8h.html", "_spatializers_2matrix_8h" ],
    [ "SimplePanner.cpp", "_simple_panner_8cpp.html", null ],
    [ "SimplePanner.h", "_simple_panner_8h.html", [
      [ "SimplePanner", "classcsl_1_1_simple_panner.html", "classcsl_1_1_simple_panner" ]
    ] ],
    [ "SimplePanner2.cpp", "_simple_panner2_8cpp.html", null ],
    [ "SimplePanner2.h", "_simple_panner2_8h.html", [
      [ "SimplePanner", "classcsl_1_1_simple_panner.html", "classcsl_1_1_simple_panner" ]
    ] ],
    [ "SpatialAudio.cpp", "_spatial_audio_8cpp.html", null ],
    [ "SpatialAudio.h", "_spatial_audio_8h.html", "_spatial_audio_8h" ],
    [ "SpatialPanner.cpp", "_spatial_panner_8cpp.html", null ],
    [ "SpatialPanner.h", "_spatial_panner_8h.html", [
      [ "SpatialPanner", "classcsl_1_1_spatial_panner.html", "classcsl_1_1_spatial_panner" ]
    ] ],
    [ "SpatialSource.cpp", "_spatial_source_8cpp.html", null ],
    [ "SpatialSource.h", "_spatial_source_8h.html", [
      [ "SpatialSource", "classcsl_1_1_spatial_source.html", "classcsl_1_1_spatial_source" ]
    ] ],
    [ "SpeakerLayout.cpp", "_speaker_layout_8cpp.html", "_speaker_layout_8cpp" ],
    [ "SpeakerLayout.h", "_speaker_layout_8h.html", [
      [ "SpeakerLayout", "classcsl_1_1_speaker_layout.html", "classcsl_1_1_speaker_layout" ],
      [ "StereoSpeakerLayout", "classcsl_1_1_stereo_speaker_layout.html", "classcsl_1_1_stereo_speaker_layout" ],
      [ "HeadphoneSpeakerLayout", "classcsl_1_1_headphone_speaker_layout.html", "classcsl_1_1_headphone_speaker_layout" ],
      [ "Speaker", "classcsl_1_1_speaker.html", "classcsl_1_1_speaker" ]
    ] ]
];