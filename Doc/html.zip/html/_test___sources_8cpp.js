var _test___sources_8cpp =
[
    [ "USE_TEST_MAIN", "_test___sources_8cpp.html#a8cb66fa186ca4331bbdb9c15a8c89117", null ],
    [ "testNoises", "_test___sources_8cpp.html#a7f5b74ac2e833ea77f7ba4d40d9e719a", null ],
    [ "testString", "_test___sources_8cpp.html#a455c6a4de69bcb9f31e44bbb2f8c75db", null ],
    [ "testStringChorus", "_test___sources_8cpp.html#a759bb955e56645aa90fa237c71bc439e", null ],
    [ "testMonoFilePlayer", "_test___sources_8cpp.html#a78fcf6e69b9f1040a57400aea94e81bd", null ],
    [ "testStereoFilePlayer", "_test___sources_8cpp.html#a573dbe267876b02713ed43465029513b", null ],
    [ "testSoundFileTranspose", "_test___sources_8cpp.html#a081852720db8b5ebb44664bb93286bec", null ],
    [ "testWaveShaper", "_test___sources_8cpp.html#a9a9825d808e107500bdb5bd9d3ed673a", null ],
    [ "testFMInstrument", "_test___sources_8cpp.html#aeb9740462d7fca4d3b70ffdd38c902cb", null ],
    [ "testSOSInstrument", "_test___sources_8cpp.html#a3a505cabf48532dd40d8abcacd5541f1", null ],
    [ "testFancyFMInstrument", "_test___sources_8cpp.html#a06e2cebf6a43a8672d636ce0d77daffd", null ],
    [ "testSndFileInstrument", "_test___sources_8cpp.html#ad6faf12eaee534dfb0abe630f89427ef", null ],
    [ "addSndtoBank", "_test___sources_8cpp.html#a23e8d880945f61b6ab43ea64645828a4", null ],
    [ "testSndFileBank", "_test___sources_8cpp.html#af067389f779c06140d8589a2935d2ef0", null ],
    [ "testGrainCloud", "_test___sources_8cpp.html#a67dd1aed5518c470e586390da3248eab", null ],
    [ "test_ifft", "_test___sources_8cpp.html#aa349cd02179e653ba38ad24d17e007b0", null ],
    [ "test_vector_ifft", "_test___sources_8cpp.html#a6d43c5fb8e7f2bea1b23b8e39a620c77", null ],
    [ "runTests", "_test___sources_8cpp.html#a5dcb537699bebb9e9db36ab19c5aacf7", null ]
];