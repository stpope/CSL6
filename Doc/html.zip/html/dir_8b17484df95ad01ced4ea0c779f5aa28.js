var dir_8b17484df95ad01ced4ea0c779f5aa28 =
[
    [ "CAIO.cpp", "_c_a_i_o_8cpp.html", "_c_a_i_o_8cpp" ],
    [ "CAIO.h", "_c_a_i_o_8h.html", [
      [ "AUIO", "classcsl_1_1_a_u_i_o.html", "classcsl_1_1_a_u_i_o" ],
      [ "CAIO", "classcsl_1_1_c_a_i_o.html", "classcsl_1_1_c_a_i_o" ]
    ] ],
    [ "FileIO.cpp", "_file_i_o_8cpp.html", null ],
    [ "FileIO.h", "_file_i_o_8h.html", [
      [ "FileIO", "classcsl_1_1_file_i_o.html", "classcsl_1_1_file_i_o" ]
    ] ],
    [ "iphoneIO.cpp", "iphone_i_o_8cpp.html", "iphone_i_o_8cpp" ],
    [ "iphoneIO.h", "iphone_i_o_8h.html", [
      [ "AUIO", "classcsl_1_1_a_u_i_o.html", "classcsl_1_1_a_u_i_o" ],
      [ "iPhoneIO", "classcsl_1_1i_phone_i_o.html", "classcsl_1_1i_phone_i_o" ]
    ] ],
    [ "JackIO.cpp", "_jack_i_o_8cpp.html", "_jack_i_o_8cpp" ],
    [ "JackIO.h", "_jack_i_o_8h.html", [
      [ "JackIO", "classcsl_1_1_jack_i_o.html", "classcsl_1_1_jack_i_o" ]
    ] ],
    [ "JUCEIO.cpp", "_j_u_c_e_i_o_8cpp.html", null ],
    [ "JUCEIO.h", "_j_u_c_e_i_o_8h.html", [
      [ "JUCEIO", "classcsl_1_1_j_u_c_e_i_o.html", "classcsl_1_1_j_u_c_e_i_o" ]
    ] ],
    [ "Microphone.cpp", "_microphone_8cpp.html", null ],
    [ "Microphone.h", "_microphone_8h.html", [
      [ "Microphone", "classcsl_1_1_microphone.html", "classcsl_1_1_microphone" ]
    ] ],
    [ "MIDIIOJ.cpp", "_m_i_d_i_i_o_j_8cpp.html", "_m_i_d_i_i_o_j_8cpp" ],
    [ "MIDIIOJ.h", "_m_i_d_i_i_o_j_8h.html", "_m_i_d_i_i_o_j_8h" ],
    [ "MIDIIOP.cpp", "_m_i_d_i_i_o_p_8cpp.html", null ],
    [ "MIDIIOP.h", "_m_i_d_i_i_o_p_8h.html", "_m_i_d_i_i_o_p_8h" ],
    [ "NullIO.cpp", "_null_i_o_8cpp.html", null ],
    [ "NullIO.h", "_null_i_o_8h.html", [
      [ "NullIO", "classcsl_1_1_null_i_o.html", "classcsl_1_1_null_i_o" ],
      [ "StdIO", "classcsl_1_1_std_i_o.html", "classcsl_1_1_std_i_o" ]
    ] ],
    [ "OSC_support.cpp", "_i_o_2_o_s_c__support_8cpp.html", null ],
    [ "OSC_support.h", "_o_s_c__support_8h.html", null ],
    [ "PAIO.cpp", "_p_a_i_o_8cpp.html", "_p_a_i_o_8cpp" ],
    [ "PAIO.h", "_p_a_i_o_8h.html", [
      [ "PAIO", "classcsl_1_1_p_a_i_o.html", "classcsl_1_1_p_a_i_o" ]
    ] ],
    [ "RemoteIO.cpp", "_remote_i_o_8cpp.html", "_remote_i_o_8cpp" ],
    [ "RemoteIO.h", "_remote_i_o_8h.html", "_remote_i_o_8h" ],
    [ "RemoteStream.cpp", "_remote_stream_8cpp.html", "_remote_stream_8cpp" ],
    [ "RemoteStream.h", "_remote_stream_8h.html", "_remote_stream_8h" ],
    [ "SoundFile.cpp", "_sound_file_8cpp.html", "_sound_file_8cpp" ],
    [ "SoundFile.h", "_sound_file_8h.html", "_sound_file_8h" ],
    [ "SoundFileCA.cpp", "_sound_file_c_a_8cpp.html", "_sound_file_c_a_8cpp" ],
    [ "SoundFileCA.h", "_sound_file_c_a_8h.html", [
      [ "CASoundFile", "classcsl_1_1_c_a_sound_file.html", "classcsl_1_1_c_a_sound_file" ]
    ] ],
    [ "SoundFileJ.cpp", "_sound_file_j_8cpp.html", null ],
    [ "SoundFileJ.h", "_sound_file_j_8h.html", [
      [ "JSoundFile", "classcsl_1_1_j_sound_file.html", "classcsl_1_1_j_sound_file" ]
    ] ],
    [ "SoundFileL.cpp", "_sound_file_l_8cpp.html", null ],
    [ "SoundFileL.h", "_sound_file_l_8h.html", [
      [ "LSoundFile", "classcsl_1_1_l_sound_file.html", "classcsl_1_1_l_sound_file" ]
    ] ],
    [ "VSTIO.cpp", "_v_s_t_i_o_8cpp.html", "_v_s_t_i_o_8cpp" ],
    [ "VSTIO.h", "_v_s_t_i_o_8h.html", [
      [ "VSTIO", "classcsl_1_1_v_s_t_i_o.html", "classcsl_1_1_v_s_t_i_o" ]
    ] ]
];