//
//  CSL_iphone_testAppDelegate.h
//  CSL_iphone_test
//
//  Created by charlie on 8/20/09.
//  Copyright One More Muse 2009. All rights reserved.
//

@class MainViewController;

@interface CSL_iphone_testAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    MainViewController *mainViewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) MainViewController *mainViewController;

@end

