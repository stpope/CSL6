//
//  CSL_Graph.h
//  CSL_iphone_test
//
//  Created by charlie on 8/21/09.
//  Copyright 2009 One More Muse. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CSL_Graph : NSObject {

}

- (void) play;

@end
