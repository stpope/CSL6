//
//  FlipsideView.h
//  CSL_iphone_test
//
//  Created by charlie on 8/20/09.
//  Copyright One More Muse 2009. All rights reserved.
//

@interface FlipsideView : UIView {
	
}

@end
