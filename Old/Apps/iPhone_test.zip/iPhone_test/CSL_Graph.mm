//
//  CSL_Graph.mm
//  CSL_iphone_test
//
//  Created by charlie on 8/21/09.
//  Copyright 2009 One More Muse. All rights reserved.
//

#import "CSL_Graph.h"
#include "Oscillator.h"
#include "Envelope.h"
#include "Mixer.h"
#include "iphoneIO.h"

@implementation CSL_Graph
using namespace csl;

void runTest(UnitGenerator & vox, double dur) {
	iPhoneIO *theIO = new iPhoneIO;
	theIO->setRoot(vox);				// set the IO's root to be the FM carrier
	theIO->open();						// open the IO
	theIO->start();						// start the driver callbacks and it plays!
	
	sleepSec(dur + 0.25);				// sleep for dur plus a bit
	logMsg("CSL done.");
	theIO->stop();						// stop the driver and close down
	theIO->close();


}

// The DSP graph is taken from the FM test example

//- (void) play {	
//	float frq = 250.0f;
//	float dur = 20.0f;
//	Sine car, mod(frq);					// declare 2 oscillators: carrier and modulator
//	ADSR a_env(dur, 0.1, 0.1, (dur - 0.6), 1);					// amplitude env = std ADSR
//	Envelope i_env(dur, 0, 0, 1, 1, 2, 0.1, 6, 1, dur, 0);// index env = time/value breakpoints
//	a_env.setScale(0.05);				// make ampl envelope quieter
//	i_env.setScale(frq * 3);			// multiply index envelope by mod freq * index depth
//	mod.setScale(i_env);				// scale the modulator by its envelope
//	mod.setOffset(frq);					// add in the base freq
//	car.setFrequency(mod);				// set the carrier's frequency
//	car.setScale(a_env);				// scale the carrier's output by the amplitude envelope
//	logMsg("CSL playing FM...");		// print a message and play
//	a_env.trigger();					// reset the envelopes to time 0
//	i_env.trigger();					// reset the envelopes to time 0
//	runTest(car, 20.0);
//}

// Other tests

- (void) play {
	Osc vox;							// declare an oscillator
	RandEnvelope a_env(4, 0.5, 0.5, 0.5); // ampl env = random (frq, amp, off, step)
	RandEnvelope f_env(3, 80, 200, 40); // freq env = random (frq, amp, off, step)
	Osc lfo(fRandM(0.3, 0.6), 1, 0, fRandM(0, CSL_PI)); // LFO with rand frq/phase
	Panner pan(vox, lfo);				// stereo panner
	vox.setFrequency(f_env);			// set the carrier's frequency
	vox.setScale(a_env);				// multiply index envelope by mod freq
	pan.setScale(0.5);					// scale softer
	logMsg("CSL playing rand osc...");	// print a message and play
	runTest(pan, 20.0);
}

@end
